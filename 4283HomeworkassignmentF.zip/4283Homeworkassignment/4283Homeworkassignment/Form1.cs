﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//This using statment is for connecting to sql
using System.Data.SqlClient;

namespace _4283Homeworkassignment
{
    public partial class Form1 : Form
    {
        /////////////////////////////////////////
        /////Connection is a variable that gets me to sql server
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader datareader;
        string connectionstring = "Data Source=essql1.walton.uark.edu; Initial Catalog=ISYS4283F2129;User ID=ISYS4283F2129;password=GohogsUA1;";
        ////////////////////////////////////////
        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////
            //Refresh button clears every txt, dgv, lst, cbo boxes
            cbocharname.SelectedIndex = -1;
            lstquestname.Items.Clear();
            dgvcampaign.DataSource = null;
            txtcharacterid.Text = "";
            txtclass.Text = "";
            txthitpoints.Text = "";
            txtplayername.Text = "";
            txtnewchar.Text = "";
            txtstatus.Text = "";
            txtdescription.Text = "";
            txtacceptdate.Text = "";
            txtdiff.Text = "";
            txtquesttype.Text = "";
            txtnpc.Text = "";
            txtreward.Text = "";
            txtnewquest.Text = "";
            txtqid.Text = "";
            ///////////////////////////////////
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ////////////////////////////////////////
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "SELECT Charater_Name FROM Charater";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while(datareader.Read())
            {
                cbocharname.Items.Add(datareader[0].ToString());
            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////////////////////////////////////
        }

        private void cbocharname_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////////////////////////////////////////
            ///Insert if statement so that the refreshing of the cbo box doesnt crash the code. else {} at bottom
            if (cbocharname.SelectedIndex > -1)
            {
                lstquestname.Items.Clear();
                connection = new SqlConnection(connectionstring);
                connection.Open();
                string sql = "SELECT Quest_Name FROM Quests";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    lstquestname.Items.Add(datareader[0].ToString());
                }
                connection.Close();
                datareader.Close();
                command.Dispose();





                connection.Open();
                sql = "SELECT Charater_ID, Hit_Points, Player_Name FROM charater WHERE Charater_Name = ' " + cbocharname.SelectedItem.ToString() + "'";
                command = new SqlCommand(sql, connection);
                datareader = command.ExecuteReader();
                while (datareader.Read())
                {
                    txtcharacterid.Text = datareader[0].ToString();
                    txtclass.Text = datareader[1].ToString();
                    txthitpoints.Text = datareader[2].ToString();
                    txtplayername.Text = datareader[3].ToString();
                }
                connection.Close();
                datareader.Close();
                command.Dispose();
            }
            else
            {

            }
            ////////////////////////////////////////
        }

        private void lstquestname_SelectedIndexChanged(object sender, EventArgs e)
        {
            ////////////////////////////////////////
            ///listbox connection to sql server
            
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "SELECT *  FROM Campaign WHERE Charater_Id = '" + txtcharacterid.Text + "'";

            var da = new SqlDataAdapter(sql, connection);
            var ds = new DataSet();
            da.Fill(ds);

            dgvcampaign.DataSource = ds.Tables[0];

            connection.Close();
            datareader.Close();
            command.Dispose();


            connection.Open();
            sql = "SELECT Quest_ID, Difficulty, Quest_Type, NPC, Reward FROM Quests WHERE Quest_Name = ' " + lstquestname.SelectedItem.ToString() + "'";
            command = new SqlCommand(sql, connection);
            datareader = command.ExecuteReader();
            while (datareader.Read())
            {
                txtqid.Text = datareader[0].ToString();
                txtdiff.Text = datareader[1].ToString();
                txtnpc.Text = datareader[2].ToString();
                txtreward.Text = datareader[3].ToString();
                txtquesttype.Text = datareader[4].ToString();


            }
            connection.Close();
            datareader.Close();
            command.Dispose();
            ////////////////////////////////////////
        }

        private void dgvcampaign_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ////////////////////////////////////////
            ///takes the text from the txt boxes
            txtstatus.Text = dgvcampaign.CurrentRow.Cells[3].Value.ToString();
            txtdescription.Text = dgvcampaign.CurrentRow.Cells[3].Value.ToString();
            txtacceptdate.Text = dgvcampaign.CurrentRow.Cells[3].Value.ToString();
            ////////////////////////////////////////
        }

        private void btncinsert_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////
            ///insert data into character
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "INSERT INTO charater VALUES (@CName, @Class, @HP, @PNAME)";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@CName", txtnewchar.Text);
            command.Parameters.AddWithValue("@Class", txtclass.Text);
            command.Parameters.AddWithValue("@HP", txthitpoints.Text);
            command.Parameters.AddWithValue("@PNAME", txtplayername.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully entered in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btncupdate_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            ///Character buttom update with error handling (try{}) and catch 
            try
            {
                connection = new SqlConnection(connectionstring);
                connection.Open();
                string sql = "UPDATE Charater SET Charater_Name=@CName, Class= @Class, Hit_points=@HP, Player_Name=@PNAME WHERE Charater_ID=@CID";
                int answer;
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("@CName", cbocharname.SelectedItem.ToString());
                command.Parameters.AddWithValue("@Class", txtclass.Text);
                command.Parameters.AddWithValue("@HP", txthitpoints.Text);
                command.Parameters.AddWithValue("@PNAME", txtplayername.Text);
                command.Parameters.AddWithValue("@CID", txtcharacterid.Text);
                answer = command.ExecuteNonQuery();

                connection.Close();
                command.Dispose();
                MessageBox.Show("Successfully updated in" + answer + "rows");
            }catch(Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btncdelete_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            /// Deletes character data
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "DELETE FROM Charater WHERE Charater_ID=@CID";
            int answer;
            command = new SqlCommand(sql, connection);
            
            command.Parameters.AddWithValue("@CID", txtcharacterid.Text);
            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully Deleted " + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnqinsert_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////
            /// Insert quests values
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "INSERT INTO Quests VALUES (@diff, @QName, @Type, @NPC, @Reward)";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@diff", txtdiff.Text);
            command.Parameters.AddWithValue("@QName", txtnewquest.Text);
            command.Parameters.AddWithValue("@Type", txtquesttype.Text);
            command.Parameters.AddWithValue("@NPC", txtnpc.Text);
            command.Parameters.AddWithValue("@Reward", txtreward.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully Entered in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnqupdate_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            ///Update quests
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "UPDATE Quests SET Difficulty= @diff, Quest_Name=@QName, Quest_Type= @Type, NPC= @NPC, Reward= @Reward WHERE Quest_ID=@QID";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@diff", txtdiff.Text);
            command.Parameters.AddWithValue("@QName", lstquestname.SelectedItem.ToString());
            command.Parameters.AddWithValue("@Type", txtquesttype.Text);
            command.Parameters.AddWithValue("@NPC", txtnpc.Text);
            command.Parameters.AddWithValue("@Reward", txtreward.Text);
            command.Parameters.AddWithValue("@QID", txtqid.Text);
            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully updated in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnqdelete_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            /// Delete quests button
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "DELETE FROM Quests WHERE Quest_ID=@QID";
            int answer;
            command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("@QID", txtqid.Text);
            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully Deleted " + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnainsert_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////
            ///
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "INSERT INTO Campaign VALUES (@CID, @QID, @Status, @Desc, @ADate)";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@CID", txtcharacterid.Text);
            command.Parameters.AddWithValue("@QID", txtqid.Text);
            command.Parameters.AddWithValue("@Status", txtstatus.Text);
            command.Parameters.AddWithValue("@Desc", txtdescription.Text);
            command.Parameters.AddWithValue("@ADate", txtacceptdate.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully Entered in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnaupdate_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            ///Update button for campaign
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "UPDATE Campaign SET Status= @Status, Description=@Desc, Accept_Date=@ADate WHERE Campaign_ID=@CAID";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@CAID", dgvcampaign.CurrentRow.Cells[0].Value.ToString());
            command.Parameters.AddWithValue("@Status", txtstatus.Text);
            command.Parameters.AddWithValue("@Desc", txtdescription.Text);
            command.Parameters.AddWithValue("@ADate", txtacceptdate.Text);

            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully updated in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void btnadelete_Click(object sender, EventArgs e)
        {
            ///////////////////////////////////////////
            /// Delete button for campaign
            try { 
            connection = new SqlConnection(connectionstring);
            connection.Open();
            string sql = "Delete FROM Campaign WHERE Campaign_ID=@CAID";
            int answer;
            command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@CAID", dgvcampaign.CurrentRow.Cells[0].Value.ToString());
            
            answer = command.ExecuteNonQuery();

            connection.Close();
            command.Dispose();
            MessageBox.Show("Successfully Deleted in" + answer + "rows");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error! please fix this issues: " + ex);
            }
            ///////////////////////////////////////////
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
