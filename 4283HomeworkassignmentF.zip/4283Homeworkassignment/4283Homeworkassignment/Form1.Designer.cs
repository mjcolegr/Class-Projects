﻿
namespace _4283Homeworkassignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbocharname = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstquestname = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvcampaign = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcharacterid = new System.Windows.Forms.TextBox();
            this.txtplayername = new System.Windows.Forms.TextBox();
            this.txthitpoints = new System.Windows.Forms.TextBox();
            this.txtclass = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtquesttype = new System.Windows.Forms.TextBox();
            this.txtnpc = new System.Windows.Forms.TextBox();
            this.txtdiff = new System.Windows.Forms.TextBox();
            this.txtreward = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtstatus = new System.Windows.Forms.TextBox();
            this.txtdescription = new System.Windows.Forms.TextBox();
            this.txtacceptdate = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btncinsert = new System.Windows.Forms.Button();
            this.btncdelete = new System.Windows.Forms.Button();
            this.btncupdate = new System.Windows.Forms.Button();
            this.btnaupdate = new System.Windows.Forms.Button();
            this.btnadelete = new System.Windows.Forms.Button();
            this.btnainsert = new System.Windows.Forms.Button();
            this.btnqupdate = new System.Windows.Forms.Button();
            this.btnqdelete = new System.Windows.Forms.Button();
            this.btnqinsert = new System.Windows.Forms.Button();
            this.btnref = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtnewchar = new System.Windows.Forms.TextBox();
            this.Newcharacter = new System.Windows.Forms.Label();
            this.txtnewquest = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtqid = new System.Windows.Forms.TextBox();
            this.Qid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvcampaign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cbocharname
            // 
            this.cbocharname.FormattingEnabled = true;
            this.cbocharname.Location = new System.Drawing.Point(82, 43);
            this.cbocharname.Name = "cbocharname";
            this.cbocharname.Size = new System.Drawing.Size(121, 21);
            this.cbocharname.TabIndex = 0;
            this.cbocharname.SelectedIndexChanged += new System.EventHandler(this.cbocharname_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(78, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose your character";
            // 
            // lstquestname
            // 
            this.lstquestname.FormattingEnabled = true;
            this.lstquestname.Location = new System.Drawing.Point(799, 67);
            this.lstquestname.Name = "lstquestname";
            this.lstquestname.Size = new System.Drawing.Size(120, 173);
            this.lstquestname.TabIndex = 2;
            this.lstquestname.SelectedIndexChanged += new System.EventHandler(this.lstquestname_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(644, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 22);
            this.label2.TabIndex = 3;
            this.label2.Text = "Select your Quest";
            // 
            // dgvcampaign
            // 
            this.dgvcampaign.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvcampaign.Location = new System.Drawing.Point(273, 193);
            this.dgvcampaign.Name = "dgvcampaign";
            this.dgvcampaign.Size = new System.Drawing.Size(240, 150);
            this.dgvcampaign.TabIndex = 4;
            this.dgvcampaign.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvcampaign_CellContentClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(292, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 5;
            this.label3.Text = "Campaigns";
            // 
            // txtcharacterid
            // 
            this.txtcharacterid.Location = new System.Drawing.Point(102, 71);
            this.txtcharacterid.Name = "txtcharacterid";
            this.txtcharacterid.Size = new System.Drawing.Size(100, 20);
            this.txtcharacterid.TabIndex = 6;
            // 
            // txtplayername
            // 
            this.txtplayername.Location = new System.Drawing.Point(103, 149);
            this.txtplayername.Name = "txtplayername";
            this.txtplayername.Size = new System.Drawing.Size(100, 20);
            this.txtplayername.TabIndex = 7;
            // 
            // txthitpoints
            // 
            this.txthitpoints.Location = new System.Drawing.Point(103, 123);
            this.txthitpoints.Name = "txthitpoints";
            this.txthitpoints.Size = new System.Drawing.Size(100, 20);
            this.txthitpoints.TabIndex = 8;
            // 
            // txtclass
            // 
            this.txtclass.Location = new System.Drawing.Point(103, 97);
            this.txtclass.Name = "txtclass";
            this.txtclass.Size = new System.Drawing.Size(100, 20);
            this.txtclass.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Charater ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 152);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Player Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Hit Points";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Class";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(742, 309);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Quest Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(775, 328);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "NPC";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(757, 253);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Difficulty";
            // 
            // txtquesttype
            // 
            this.txtquesttype.Location = new System.Drawing.Point(810, 302);
            this.txtquesttype.Name = "txtquesttype";
            this.txtquesttype.Size = new System.Drawing.Size(100, 20);
            this.txtquesttype.TabIndex = 16;
            // 
            // txtnpc
            // 
            this.txtnpc.Location = new System.Drawing.Point(810, 325);
            this.txtnpc.Name = "txtnpc";
            this.txtnpc.Size = new System.Drawing.Size(100, 20);
            this.txtnpc.TabIndex = 15;
            // 
            // txtdiff
            // 
            this.txtdiff.Location = new System.Drawing.Point(810, 250);
            this.txtdiff.Name = "txtdiff";
            this.txtdiff.Size = new System.Drawing.Size(100, 20);
            this.txtdiff.TabIndex = 14;
            // 
            // txtreward
            // 
            this.txtreward.Location = new System.Drawing.Point(810, 348);
            this.txtreward.Name = "txtreward";
            this.txtreward.Size = new System.Drawing.Size(100, 20);
            this.txtreward.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(764, 351);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Reward";
            // 
            // txtstatus
            // 
            this.txtstatus.Location = new System.Drawing.Point(368, 360);
            this.txtstatus.Name = "txtstatus";
            this.txtstatus.Size = new System.Drawing.Size(100, 20);
            this.txtstatus.TabIndex = 26;
            // 
            // txtdescription
            // 
            this.txtdescription.Location = new System.Drawing.Point(368, 386);
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(100, 20);
            this.txtdescription.TabIndex = 25;
            // 
            // txtacceptdate
            // 
            this.txtacceptdate.Location = new System.Drawing.Point(368, 412);
            this.txtacceptdate.Name = "txtacceptdate";
            this.txtacceptdate.Size = new System.Drawing.Size(100, 20);
            this.txtacceptdate.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(293, 360);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(293, 389);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "Description";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(293, 412);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(67, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "Accept Date";
            // 
            // btncinsert
            // 
            this.btncinsert.Location = new System.Drawing.Point(20, 217);
            this.btncinsert.Name = "btncinsert";
            this.btncinsert.Size = new System.Drawing.Size(75, 23);
            this.btncinsert.TabIndex = 30;
            this.btncinsert.Text = "Insert";
            this.btncinsert.UseVisualStyleBackColor = true;
            this.btncinsert.Click += new System.EventHandler(this.btncinsert_Click);
            // 
            // btncdelete
            // 
            this.btncdelete.Location = new System.Drawing.Point(20, 248);
            this.btncdelete.Name = "btncdelete";
            this.btncdelete.Size = new System.Drawing.Size(75, 23);
            this.btncdelete.TabIndex = 31;
            this.btncdelete.Text = "Delete";
            this.btncdelete.UseVisualStyleBackColor = true;
            this.btncdelete.Click += new System.EventHandler(this.btncdelete_Click);
            // 
            // btncupdate
            // 
            this.btncupdate.Location = new System.Drawing.Point(128, 217);
            this.btncupdate.Name = "btncupdate";
            this.btncupdate.Size = new System.Drawing.Size(75, 23);
            this.btncupdate.TabIndex = 32;
            this.btncupdate.Text = "Update";
            this.btncupdate.UseVisualStyleBackColor = true;
            this.btncupdate.Click += new System.EventHandler(this.btncupdate_Click);
            // 
            // btnaupdate
            // 
            this.btnaupdate.Location = new System.Drawing.Point(378, 444);
            this.btnaupdate.Name = "btnaupdate";
            this.btnaupdate.Size = new System.Drawing.Size(75, 23);
            this.btnaupdate.TabIndex = 35;
            this.btnaupdate.Text = "Update";
            this.btnaupdate.UseVisualStyleBackColor = true;
            this.btnaupdate.Click += new System.EventHandler(this.btnaupdate_Click);
            // 
            // btnadelete
            // 
            this.btnadelete.Location = new System.Drawing.Point(285, 473);
            this.btnadelete.Name = "btnadelete";
            this.btnadelete.Size = new System.Drawing.Size(75, 23);
            this.btnadelete.TabIndex = 34;
            this.btnadelete.Text = "Delete";
            this.btnadelete.UseVisualStyleBackColor = true;
            this.btnadelete.Click += new System.EventHandler(this.btnadelete_Click);
            // 
            // btnainsert
            // 
            this.btnainsert.Location = new System.Drawing.Point(285, 444);
            this.btnainsert.Name = "btnainsert";
            this.btnainsert.Size = new System.Drawing.Size(75, 23);
            this.btnainsert.TabIndex = 33;
            this.btnainsert.Text = "Insert";
            this.btnainsert.UseVisualStyleBackColor = true;
            this.btnainsert.Click += new System.EventHandler(this.btnainsert_Click);
            // 
            // btnqupdate
            // 
            this.btnqupdate.Location = new System.Drawing.Point(814, 444);
            this.btnqupdate.Name = "btnqupdate";
            this.btnqupdate.Size = new System.Drawing.Size(75, 23);
            this.btnqupdate.TabIndex = 38;
            this.btnqupdate.Text = "Update";
            this.btnqupdate.UseVisualStyleBackColor = true;
            this.btnqupdate.Click += new System.EventHandler(this.btnqupdate_Click);
            // 
            // btnqdelete
            // 
            this.btnqdelete.Location = new System.Drawing.Point(733, 473);
            this.btnqdelete.Name = "btnqdelete";
            this.btnqdelete.Size = new System.Drawing.Size(75, 23);
            this.btnqdelete.TabIndex = 37;
            this.btnqdelete.Text = "Delete";
            this.btnqdelete.UseVisualStyleBackColor = true;
            this.btnqdelete.Click += new System.EventHandler(this.btnqdelete_Click);
            // 
            // btnqinsert
            // 
            this.btnqinsert.Location = new System.Drawing.Point(733, 444);
            this.btnqinsert.Name = "btnqinsert";
            this.btnqinsert.Size = new System.Drawing.Size(75, 23);
            this.btnqinsert.TabIndex = 36;
            this.btnqinsert.Text = "Insert";
            this.btnqinsert.UseVisualStyleBackColor = true;
            this.btnqinsert.Click += new System.EventHandler(this.btnqinsert_Click);
            // 
            // btnref
            // 
            this.btnref.Location = new System.Drawing.Point(24, 549);
            this.btnref.Name = "btnref";
            this.btnref.Size = new System.Drawing.Size(75, 23);
            this.btnref.TabIndex = 39;
            this.btnref.Text = "Refresh";
            this.btnref.UseVisualStyleBackColor = true;
            this.btnref.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(127, 549);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 23);
            this.btnexit.TabIndex = 40;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.button11_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_4283Homeworkassignment.Properties.Resources.knight_demon_souls_wiki_guide;
            this.pictureBox1.Location = new System.Drawing.Point(303, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(339, 157);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // txtnewchar
            // 
            this.txtnewchar.Location = new System.Drawing.Point(102, 175);
            this.txtnewchar.Name = "txtnewchar";
            this.txtnewchar.Size = new System.Drawing.Size(100, 20);
            this.txtnewchar.TabIndex = 42;
            // 
            // Newcharacter
            // 
            this.Newcharacter.AutoSize = true;
            this.Newcharacter.Location = new System.Drawing.Point(21, 182);
            this.Newcharacter.Name = "Newcharacter";
            this.Newcharacter.Size = new System.Drawing.Size(78, 13);
            this.Newcharacter.TabIndex = 43;
            this.Newcharacter.Text = "New Character";
            // 
            // txtnewquest
            // 
            this.txtnewquest.Location = new System.Drawing.Point(810, 373);
            this.txtnewquest.Name = "txtnewquest";
            this.txtnewquest.Size = new System.Drawing.Size(100, 20);
            this.txtnewquest.TabIndex = 44;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(744, 380);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 45;
            this.label16.Text = "New Quest";
            // 
            // txtqid
            // 
            this.txtqid.Location = new System.Drawing.Point(810, 276);
            this.txtqid.Name = "txtqid";
            this.txtqid.Size = new System.Drawing.Size(100, 20);
            this.txtqid.TabIndex = 46;
            // 
            // Qid
            // 
            this.Qid.AutoSize = true;
            this.Qid.Location = new System.Drawing.Point(757, 279);
            this.Qid.Name = "Qid";
            this.Qid.Size = new System.Drawing.Size(47, 13);
            this.Qid.TabIndex = 47;
            this.Qid.Text = "Quest Id";
            this.Qid.Click += new System.EventHandler(this.label8_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 625);
            this.Controls.Add(this.Qid);
            this.Controls.Add(this.txtqid);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtnewquest);
            this.Controls.Add(this.Newcharacter);
            this.Controls.Add(this.txtnewchar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnref);
            this.Controls.Add(this.btnqupdate);
            this.Controls.Add(this.btnqdelete);
            this.Controls.Add(this.btnqinsert);
            this.Controls.Add(this.btnaupdate);
            this.Controls.Add(this.btnadelete);
            this.Controls.Add(this.btnainsert);
            this.Controls.Add(this.btncupdate);
            this.Controls.Add(this.btncdelete);
            this.Controls.Add(this.btncinsert);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtstatus);
            this.Controls.Add(this.txtdescription);
            this.Controls.Add(this.txtacceptdate);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtreward);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtquesttype);
            this.Controls.Add(this.txtnpc);
            this.Controls.Add(this.txtdiff);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtclass);
            this.Controls.Add(this.txthitpoints);
            this.Controls.Add(this.txtplayername);
            this.Controls.Add(this.txtcharacterid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvcampaign);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstquestname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbocharname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvcampaign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbocharname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstquestname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvcampaign;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcharacterid;
        private System.Windows.Forms.TextBox txtplayername;
        private System.Windows.Forms.TextBox txthitpoints;
        private System.Windows.Forms.TextBox txtclass;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtquesttype;
        private System.Windows.Forms.TextBox txtnpc;
        private System.Windows.Forms.TextBox txtdiff;
        private System.Windows.Forms.TextBox txtreward;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtstatus;
        private System.Windows.Forms.TextBox txtdescription;
        private System.Windows.Forms.TextBox txtacceptdate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btncinsert;
        private System.Windows.Forms.Button btncdelete;
        private System.Windows.Forms.Button btncupdate;
        private System.Windows.Forms.Button btnaupdate;
        private System.Windows.Forms.Button btnadelete;
        private System.Windows.Forms.Button btnainsert;
        private System.Windows.Forms.Button btnqupdate;
        private System.Windows.Forms.Button btnqdelete;
        private System.Windows.Forms.Button btnqinsert;
        private System.Windows.Forms.Button btnref;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtnewchar;
        private System.Windows.Forms.Label Newcharacter;
        private System.Windows.Forms.TextBox txtnewquest;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtqid;
        private System.Windows.Forms.Label Qid;
    }
}

